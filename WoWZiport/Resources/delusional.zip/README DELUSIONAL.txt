----------------------------
Copyright (c) 2016, ALY K. SALAZAR
----------------------------
"DELUSIONAL" is free for personal use and $15 for commercial use. In order to pay, please donate to my paypal account through dafont. Do not edit, resell, or otherwise reclaim my work as your own. DO NOT REDISTRIBUTE. "www.dafont.com" is the only website authorized to host this font. If you downloaded this font from another source that was NOT dafont.com, it is an unauthorized copy, which was uploaded without the author's consent and/or knowledge.

THANK YOU FOR DOWNLOADING!